import type { Monitor } from '../types/monitor';

const STORAGE_KEY = 'itseam_monitors';

export function saveMonitors(monitors: Monitor[]): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(monitors));
}

export function loadMonitors(): Monitor[] {
  const stored = localStorage.getItem(STORAGE_KEY);
  if (!stored) return [];
  
  try {
    const monitors = JSON.parse(stored);
    // Tarihleri string'den Date objesine çeviriyoruz
    return monitors.map((monitor: any) => ({
      ...monitor,
      lastChecked: monitor.lastChecked ? new Date(monitor.lastChecked) : undefined,
      downtime: monitor.downtime ? new Date(monitor.downtime) : undefined
    }));
  } catch (error) {
    console.error('Monitor verilerini yüklerken hata:', error);
    return [];
  }
}