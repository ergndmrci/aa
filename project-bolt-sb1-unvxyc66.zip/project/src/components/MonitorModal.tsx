import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { Monitor, MonitorType } from '../types/monitor';
import { COMMON_PORTS } from '../constants/ports';

interface MonitorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (monitor: any) => void;
  initialData?: Monitor | null;
}

export function MonitorModal({ isOpen, onClose, onSubmit, initialData }: MonitorModalProps) {
  const [type, setType] = useState<MonitorType>('ping');
  const [formData, setFormData] = useState({
    name: '',
    target: '',
    port: '',
    email: ''
  });

  useEffect(() => {
    if (initialData) {
      setType(initialData.type);
      setFormData({
        name: initialData.name,
        target: initialData.target,
        port: initialData.port?.toString() || '',
        email: initialData.email
      });
    } else {
      setType('ping');
      setFormData({
        name: '',
        target: '',
        port: '',
        email: ''
      });
    }
  }, [initialData]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const monitorData = {
      ...formData,
      type,
      port: type === 'port' ? parseInt(formData.port, 10) : undefined,
    };

    if (initialData) {
      onSubmit({
        ...initialData,
        ...monitorData,
      });
    } else {
      onSubmit(monitorData);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center">
      <div className="bg-gray-900 p-6 rounded-lg w-full max-w-md border border-green-500/20">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-green-400 text-xl font-medium">
            {initialData ? 'Monitör Düzenle' : 'Yeni Monitör Ekle'}
          </h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-300">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-gray-300 mb-1">Monitör Tipi</label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setType('ping')}
                className={`p-2 rounded ${
                  type === 'ping' 
                    ? 'bg-green-600 text-white' 
                    : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                }`}
              >
                Ping Monitoring
              </button>
              <button
                type="button"
                onClick={() => setType('port')}
                className={`p-2 rounded ${
                  type === 'port' 
                    ? 'bg-green-600 text-white' 
                    : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                }`}
              >
                Port Monitoring
              </button>
            </div>
          </div>

          <div>
            <label className="block text-gray-300 mb-1">Monitör Adı</label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
              className="w-full bg-gray-800 border border-gray-700 rounded p-2 text-gray-200"
              required
            />
          </div>

          <div>
            <label className="block text-gray-300 mb-1">Hedef (URL/IP)</label>
            <input
              type="text"
              value={formData.target}
              onChange={(e) => setFormData(prev => ({ ...prev, target: e.target.value }))}
              className="w-full bg-gray-800 border border-gray-700 rounded p-2 text-gray-200"
              required
            />
          </div>

          {type === 'port' && (
            <div>
              <label className="block text-gray-300 mb-1">Port</label>
              <select
                value={formData.port}
                onChange={(e) => setFormData(prev => ({ ...prev, port: e.target.value }))}
                className="w-full bg-gray-800 border border-gray-700 rounded p-2 text-gray-200"
                required
              >
                <option value="">Port Seçin</option>
                {COMMON_PORTS.map(port => (
                  <option key={port.value} value={port.value}>
                    {port.label} ({port.value})
                  </option>
                ))}
              </select>
            </div>
          )}

          <div>
            <label className="block text-gray-300 mb-1">Bildirim E-postası</label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
              className="w-full bg-gray-800 border border-gray-700 rounded p-2 text-gray-200"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full bg-green-600 hover:bg-green-700 text-white py-2 rounded transition-colors"
          >
            {initialData ? 'Güncelle' : 'Monitör Ekle'}
          </button>
        </form>
      </div>
    </div>
  );
}