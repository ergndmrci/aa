import React from 'react';
import { Activity, CheckCircle2, XCircle } from 'lucide-react';
import type { Monitor } from '../types/monitor';

interface StatusOverviewProps {
  monitors: Monitor[];
}

export function StatusOverview({ monitors }: StatusOverviewProps) {
  const activeMonitors = monitors.filter(m => !m.isPaused);
  const upCount = activeMonitors.filter(m => m.status === 'up').length;
  const downCount = activeMonitors.filter(m => m.status === 'down').length;
  
  const totalUptime = activeMonitors.length > 0
    ? Math.round(activeMonitors.reduce((acc, m) => acc + m.uptime, 0) / activeMonitors.length)
    : 0;

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
      <div className="bg-gray-900 p-6 rounded-lg border border-green-500/20">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-gray-400 text-sm">Toplam Monitör</p>
            <p className="text-2xl font-bold text-green-400">{monitors.length}</p>
          </div>
          <Activity className="w-8 h-8 text-green-400" />
        </div>
      </div>

      <div className="bg-gray-900 p-6 rounded-lg border border-green-500/20">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-gray-400 text-sm">Çalışan Servisler</p>
            <p className="text-2xl font-bold text-green-400">{upCount}</p>
          </div>
          <CheckCircle2 className="w-8 h-8 text-green-400" />
        </div>
      </div>

      <div className="bg-gray-900 p-6 rounded-lg border border-green-500/20">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-gray-400 text-sm">Kesintideki Servisler</p>
            <p className="text-2xl font-bold text-red-400">{downCount}</p>
          </div>
          <XCircle className="w-8 h-8 text-red-400" />
        </div>
      </div>
    </div>
  );
}