import React from 'react';
import { Activity, Pause, Play, Edit, Trash2 } from 'lucide-react';
import type { Monitor } from '../types/monitor';
import { formatUptime } from '../utils/formatters';
import { ResponseTimeChart } from './ResponseTimeChart';

interface MonitorListProps {
  monitors: Monitor[];
  onDelete: (id: string) => void;
  onTogglePause: (id: string) => void;
  onEdit: (monitor: Monitor) => void;
}

export function MonitorList({ monitors, onDelete, onTogglePause, onEdit }: MonitorListProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
      {monitors.map((monitor) => (
        <div
          key={monitor.id}
          className="bg-gray-900 p-4 rounded-lg border border-green-500/20 hover:border-green-500/40 transition-all"
        >
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${
                monitor.isPaused ? 'bg-yellow-500' :
                monitor.status === 'up' ? 'bg-green-500' : 
                monitor.status === 'down' ? 'bg-red-500' : 
                'bg-yellow-500'
              }`} />
              <h3 className="text-green-400 text-sm font-medium truncate max-w-[150px]">{monitor.name}</h3>
            </div>
            <div className="flex items-center gap-1">
              <button
                onClick={() => onTogglePause(monitor.id)}
                className="p-1 rounded hover:bg-gray-800 text-gray-400 hover:text-gray-300 transition-colors"
                title={monitor.isPaused ? 'Devam Et' : 'Duraklat'}
              >
                {monitor.isPaused ? <Play size={14} /> : <Pause size={14} />}
              </button>
              <button
                onClick={() => onEdit(monitor)}
                className="p-1 rounded hover:bg-gray-800 text-gray-400 hover:text-gray-300 transition-colors"
                title="Düzenle"
              >
                <Edit size={14} />
              </button>
              <button
                onClick={() => onDelete(monitor.id)}
                className="p-1 rounded hover:bg-gray-800 text-gray-400 hover:text-red-400 transition-colors"
                title="Sil"
              >
                <Trash2 size={14} />
              </button>
            </div>
          </div>

          <div className="space-y-1 text-xs">
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Hedef:</span>
              <span className="text-green-300 truncate max-w-[180px]">
                {monitor.target}
                {monitor.port ? `:${monitor.port}` : ''}
              </span>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-gray-400">Uptime:</span>
              <div className="flex items-center gap-1">
                <div className="w-20 h-1.5 bg-gray-700 rounded-full">
                  <div 
                    className="h-full bg-green-500 rounded-full"
                    style={{ width: `${monitor.uptime}%` }}
                  />
                </div>
                <span className="text-green-400">{monitor.uptime}%</span>
              </div>
            </div>

            {monitor.downtime && (
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Kesinti:</span>
                <span className="text-red-400">{formatUptime(monitor.downtime)}</span>
              </div>
            )}

            <div className="pt-1">
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Response:</span>
                <span className="text-green-300">
                  {monitor.responseTimes.length > 0
                    ? `${monitor.responseTimes[monitor.responseTimes.length - 1].value}ms`
                    : 'N/A'}
                </span>
              </div>
              <ResponseTimeChart data={monitor.responseTimes} />
            </div>
          </div>
        </div>
      ))}
      
      {monitors.length === 0 && (
        <div className="text-center py-8 text-gray-400 col-span-full">
          Henüz monitör eklenmemiş
        </div>
      )}
    </div>
  );
}