import React from 'react';
import { Plus } from 'lucide-react';

interface AddMonitorButtonProps {
  onClick: () => void;
}

export function AddMonitorButton({ onClick }: AddMonitorButtonProps) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors"
    >
      <Plus className="w-5 h-5" />
      Yeni Monitör
    </button>
  );
}