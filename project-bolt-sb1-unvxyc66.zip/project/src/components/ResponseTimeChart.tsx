import React from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import type { ResponseTime } from '../types/monitor';

interface ResponseTimeChartProps {
  data: ResponseTime[];
}

export function ResponseTimeChart({ data }: ResponseTimeChartProps) {
  const formatTime = (timestamp: number) => {
    const date = new Date(timestamp);
    return `${date.getHours()}:${date.getMinutes().toString().padStart(2, '0')}`;
  };

  return (
    <div className="h-24 w-full mt-2">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <XAxis
            dataKey="timestamp"
            tickFormatter={formatTime}
            stroke="#6B7280"
            fontSize={8}
            tickSize={2}
          />
          <YAxis
            stroke="#6B7280"
            fontSize={8}
            tickSize={2}
            tickFormatter={(value) => `${value}ms`}
          />
          <Tooltip
            contentStyle={{ background: '#1F2937', border: 'none', fontSize: '12px', padding: '4px 8px' }}
            labelStyle={{ color: '#9CA3AF' }}
            formatter={(value) => [`${value}ms`, 'Response Time']}
            labelFormatter={(label) => formatTime(label as number)}
          />
          <Line
            type="monotone"
            dataKey="value"
            stroke="#10B981"
            strokeWidth={1.5}
            dot={false}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}