export type MonitorType = 'ping' | 'port';
export type MonitorStatus = 'up' | 'down' | 'pending';

export interface ResponseTime {
  timestamp: number;
  value: number;
}

export interface Monitor {
  id: string;
  name: string;
  target: string;
  type: MonitorType;
  port?: number;
  status: MonitorStatus;
  uptime: number;
  lastChecked?: Date;
  downtime?: Date;
  email: string;
  isPaused: boolean;
  responseTimes: ResponseTime[];
}