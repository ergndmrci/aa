import { PortOption } from '../types/monitor';

export const COMMON_PORTS: PortOption[] = [
  { label: 'HTTP', value: 80, protocol: 'TCP' },
  { label: 'HTTPS', value: 443, protocol: 'TCP' },
  { label: 'DNS', value: 53, protocol: 'UDP' },
  { label: 'FTP', value: 21, protocol: 'TCP' },
  { label: 'SSH', value: 22, protocol: 'TCP' },
  { label: 'SMTP', value: 25, protocol: 'TCP' },
  { label: 'POP3', value: 110, protocol: 'TCP' },
  { label: 'IMAP', value: 143, protocol: 'TCP' },
  { label: 'SQL Server', value: 1433, protocol: 'TCP' },
  { label: 'MySQL', value: 3306, protocol: 'TCP' },
];