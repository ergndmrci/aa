import { useState, useEffect } from 'react';
import { saveMonitors, loadMonitors } from '../utils/storage';
import type { Monitor } from '../types/monitor';

export function useMonitorState() {
  const [monitors, setMonitors] = useState<Monitor[]>(() => loadMonitors());

  useEffect(() => {
    saveMonitors(monitors);
  }, [monitors]);

  useEffect(() => {
    const interval = setInterval(() => {
      setMonitors(current =>
        current.map(monitor => {
          if (monitor.isPaused) return monitor;

          const newResponseTime = {
            timestamp: Date.now(),
            value: Math.floor(Math.random() * 200 + 50)
          };

          const responseTimes = [...monitor.responseTimes, newResponseTime]
            .slice(-20);

          return {
            ...monitor,
            status: Math.random() > 0.1 ? 'up' : 'down',
            uptime: Math.floor(Math.random() * 20 + 80),
            lastChecked: new Date(),
            downtime: monitor.status === 'down' ? new Date() : undefined,
            responseTimes
          };
        })
      );
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const handleAddMonitor = (newMonitor: Omit<Monitor, 'id' | 'status' | 'uptime' | 'isPaused' | 'responseTimes'>) => {
    const monitor: Monitor = {
      ...newMonitor,
      id: Date.now().toString(),
      status: 'pending',
      uptime: 100,
      isPaused: false,
      responseTimes: []
    };
    setMonitors(prev => [...prev, monitor]);
  };

  const handleEditMonitor = (updatedMonitor: Monitor) => {
    setMonitors(prev => prev.map(m => 
      m.id === updatedMonitor.id ? updatedMonitor : m
    ));
  };

  const handleTogglePause = (id: string) => {
    setMonitors(prev => prev.map(m =>
      m.id === id ? { ...m, isPaused: !m.isPaused } : m
    ));
  };

  const handleDeleteMonitor = (id: string) => {
    setMonitors(prev => prev.filter(m => m.id !== id));
  };

  return {
    monitors,
    handleAddMonitor,
    handleEditMonitor,
    handleTogglePause,
    handleDeleteMonitor
  };
}